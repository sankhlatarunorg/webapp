#!/bin/bash
mkdir -p /home/webapp
cp webapp.zip /home/webapp
